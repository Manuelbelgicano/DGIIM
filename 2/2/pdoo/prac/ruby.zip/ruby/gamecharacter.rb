#encoding:utf-8
module Deepspace
  # Tipos de personajes
  module GameCharacter
    ENEMYSTARSHIP = :enemystarship
    SPACESTATION = :spacestation
  end
end
