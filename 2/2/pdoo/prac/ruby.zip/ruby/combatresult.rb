#encoding:utf-8
module Deepspace
# Resultados posibles de un combate
  module CombatResult
    ENEMYWINS = :enemywins
    NOCOMBAT = :nocombat
    STATIONESCAPES = :stationscapes
    STATIONWINS = :stationwins
  end
end
